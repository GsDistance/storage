# GsD File Storage

This repository is used to statically host files for the GsDistance website and related projects.

## Structure

- `store` directory contains the files to be hosted.
- `store_contents.json` contains the list of files in the store directory.

