As GsDistance, we're only using the open source version of font awesome and hosting it for ourselves. 
All credits for font awesome goes to Fonticons, Inc.